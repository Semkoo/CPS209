import java.awt.Graphics2D;


public abstract class Creature implements MoveableShape 
{
	private int xPos;
	private int yPos;
	private int width;
	private int height;
	public  static int environmentWidth;
	public  static int environmentHeight;
	
	public Creature()
	{
	   xPos = 0;
	   yPos = 0;
	}

	public Creature(int x, int y)
	{
		xPos = x;
	    yPos = y;
	}
	
	public Creature(int x, int y, int width, int height, int envW, int envH)
	{
		xPos = x;
	    yPos = y;
	    this.width  = width;
	    this.height = height;
	    this.environmentWidth  = envW;
	    this.environmentHeight = envH;
	}
	   
	public int getX()
	{
	   return xPos;
	}
	   
	public int getY()
	{
	   return yPos;
	}
	
	public void setX(int x)
	{
	   xPos = x;
	}
	   
	public void setY(int y)
	{
	   yPos = y;
	}
	
	public int getWidth()
	{
	   return width;
	}
	   
	public int getHeight()
	{
	   return height;
	}
	
	public String toString()
	{
	   String str = "(X,Y) Position: (" + xPos + "," + yPos + ")\n";
	   return str;
	}
	
	
}
