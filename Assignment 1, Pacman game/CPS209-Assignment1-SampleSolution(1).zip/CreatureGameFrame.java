import javax.swing.JFrame ;
import javax.swing.JButton ;
import javax.swing.JPanel ;
import javax.swing.border.Border;

import java.awt.event.ActionListener ;
import java.awt.event.ActionEvent ;
import java.awt.BorderLayout ;
import java.awt.Dimension;
import java.awt.Rectangle;

public class CreatureGameFrame extends JFrame
{
    public static final int FRAME_WIDTH  = 300;
    public static final int FRAME_HEIGHT = 400;

    /**
       Constructs the frame
     */
    public CreatureGameFrame()
    {
    	createPanel() ;
    	
    }
    
    /**
       Creates a panel with some circles
     */
    public void createPanel()
    {
    	JPanel panel = new CreatureGamePanel() ;
    	getContentPane().add(panel);
	}
}
