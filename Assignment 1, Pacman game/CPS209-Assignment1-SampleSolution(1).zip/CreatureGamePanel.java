import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.geom.*;
import java.awt.Dimension ;
import java.awt.Color;
import java.util.Random ;
import java.util.ArrayList ;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener ;
import java.awt.event.MouseAdapter ;
import java.awt.event.MouseEvent ;

public class CreatureGamePanel extends JPanel
{  
	// The prey
    ArrayList<Creature> preyCreatures ;
    
    // The predator
    Predator predator;
    
    Random random = new Random() ;
    
    boolean gameStart;
    
    static int hundrethSeconds = 0;
    
    final int PREDATORSIZE = 30 ;
    final int PREYSIZE1    = 20 ;
    final int PREYSIZE2    = 10 ;
    final int NUMBER_PREYCREATURES =  50 ;
        
    public CreatureGamePanel()
    {
    	gameStart = false;
    	
    	// Create predator     	
    	predator = new Predator(0, 20, PREDATORSIZE, PREDATORSIZE,CreatureGameFrame.FRAME_WIDTH,
    			                                                  CreatureGameFrame.FRAME_HEIGHT);
    	// Create prey creatures
    	preyCreatures = new ArrayList<Creature>() ;
    	
    	for (int i = 0 ; i < NUMBER_PREYCREATURES ; i ++) 
    	{
    		Creature prey;
    		// Every 10th prey creature is a smart prey 
    		if (i%10 == 0)
    		{
    			prey = new SmartPrey(random.nextInt(CreatureGameFrame.FRAME_WIDTH),
                                     random.nextInt(CreatureGameFrame.FRAME_HEIGHT),
                                     PREYSIZE1,PREYSIZE1,
                                     CreatureGameFrame.FRAME_WIDTH,
                                     CreatureGameFrame.FRAME_HEIGHT);
    		}
    		else
    		{
    			prey = new SlowPrey(random.nextInt(CreatureGameFrame.FRAME_WIDTH),
                                    random.nextInt(CreatureGameFrame.FRAME_HEIGHT),
                                    PREYSIZE2,PREYSIZE2,
                                    CreatureGameFrame.FRAME_WIDTH,
                                    CreatureGameFrame.FRAME_HEIGHT);
                                            
    		}
    		preyCreatures.add(prey);
    	}
    	
    	// Main Game Loop
    	class AnimationTimerListener implements ActionListener
        {
       	 public void actionPerformed(ActionEvent event)
         {
       		 if (!gameStart) 
       			 return;
       		 
       		 hundrethSeconds++;
       		        		 
       		 // Move all creatures
       		 predator.move();
       		 
       		 for (MoveableShape prey : preyCreatures)
       		 {
       			 prey.move();
       		 }
       		 
       	     // Check if prey sense predator 
       		 for (MoveableShape prey: preyCreatures) 
       		 {
       			// Check for collision
	    		prey.collide(predator);
       		 } 

       		 // Check if predator can eat prey 
       		 for (MoveableShape prey: preyCreatures) 
       		 {
       			// Check for collision
	    		if (predator.collide(prey))
		   		{
	    			// Predator "eats" prey
					preyCreatures.remove(prey);
					break;
		   		}
       		 } 
       		 
       		 // Check for game over
       		 if (preyCreatures.size() == 0)
       			 gameStart = false;
       		
       		 repaint();
         }
        }
        // Create ActionListener object for the Animation Timer
        ActionListener animationTimerListener = new AnimationTimerListener();
        Timer animationTimer = new Timer(10,animationTimerListener);
    	animationTimer.start();
    		    
    	// Set up mouse button event handling
    	// Controls direction of predator creature
    	class MyListener extends MouseAdapter
    	{
    		public void mousePressed(MouseEvent event)
    		{
    			// First time button is pressed, start game
    			if (!gameStart) gameStart = true;
		        
    			if (event.getButton()== event.BUTTON1)
		        	predator.turnCCW();
		        else if (event.getButton()== event.BUTTON3)
		        	predator.turnCW();
    			
    			repaint() ;
    		}
    	}
		addMouseListener(new MyListener()) ;
	} // end constructor method
    
    public void paintComponent(Graphics g)
    {  
    	super.paintComponent(g) ;
    	Graphics2D g2 = (Graphics2D) g;
    	
    	// Elapsed time
    	g2.drawString(""+hundrethSeconds/60, 10,10);
    	
    	// Draw prey creatures
    	for (MoveableShape prey: preyCreatures) 
    		prey.draw(g2);
    	
    	//Draw predator
		predator.draw(g2);
	}
} // end Component
