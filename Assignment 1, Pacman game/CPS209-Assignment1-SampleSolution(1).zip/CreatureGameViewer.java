import javax.swing.JFrame; 

import java.awt.Dimension;
import java.awt.Graphics; 
import java.awt.Graphics2D; 
import java.awt.Rectangle; 
import javax.swing.JPanel; 
import javax.swing.JComponent; 
import java.awt.geom.*; 
import java.awt.Color;  

public class CreatureGameViewer 
{     
	public static void main(String[] args)     
	{ 	
		JFrame frame = new CreatureGameFrame(); 	
		frame.setTitle("Pacman"); 	
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 	
		frame.getContentPane().setPreferredSize(new Dimension(300,400));
		frame.pack();
		frame.setVisible(true) ;     
	} 
}