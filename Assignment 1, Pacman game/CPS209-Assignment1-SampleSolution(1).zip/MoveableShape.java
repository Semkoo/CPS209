import java.awt.Graphics2D;
/*
 * Interface MoveableShape imposes the ability to move and draw a geometric shape on each class that
 * implements it. 
 * It also imposes the ability to check for collisions between another MoveableShape object  
 */

public interface MoveableShape 
{
   void move();
   boolean collide(MoveableShape other);
   void draw(Graphics2D g2);
}
