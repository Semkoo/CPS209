import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;


public class Predator extends Creature
{
	int xDir = 1;
	int yDir = 0;
	Ellipse2D.Double body;
	
	class DirectionDelta
    {
    	int x;
    	int y;
    }
	DirectionDelta[] directionDelta;
	int currentDirection;
	
	public Predator(int x, int y, int width, int height, int envW, int envH)
	{
		super(x, y, width, height, envW, envH);
	    body = new Ellipse2D.Double(x,y,width,height);
	
	    directionDelta = new DirectionDelta[4];
		currentDirection = 0;
		directionDelta[0] = new DirectionDelta();
	    directionDelta[0].x =  1;
	    directionDelta[0].y =  0;
	    directionDelta[1] = new DirectionDelta();
	    directionDelta[1].x =  0;
	    directionDelta[1].y =  1;
	    directionDelta[2] = new DirectionDelta();
	    directionDelta[2].x = -1;
	    directionDelta[2].y =  0;
	    directionDelta[3] = new DirectionDelta();
	    directionDelta[3].x =  0;
	    directionDelta[3].y = -1;
	    
	}
	
	public void turnCCW()
	{
		currentDirection = (currentDirection - 1 < 0)? 3 : currentDirection - 1;
    }
	
	public void turnCW()
	{
		currentDirection = (currentDirection + 1)%4;
    }
	
	public boolean collide(MoveableShape other)
	{
		Creature otherCreature = (Creature)other;
		
		if (body.contains(otherCreature.getX()+ otherCreature.getWidth()/2,
			              otherCreature.getY()+ otherCreature.getHeight()/2))
			return true;
				          
		return false;
	}
	
	public void move()
	{
		int newX = (int)body.getX() + directionDelta[currentDirection].x;
		int newY = (int)body.getY() + directionDelta[currentDirection].y;
		
		if (newX+getWidth() >= environmentWidth)
			newX = environmentWidth - getWidth();
		else if (newX <= 0)
			newX = 1;
		if (newY <= 0)
			newY = 1;
		else if ((newY+getHeight()) >= environmentHeight)
			newY = environmentHeight - getHeight();
		
		setX(newX);
		setY(newY);
  		body.setFrame(newX, newY, body.getWidth(), body.getHeight());
	}
	public void draw(Graphics2D g2)
	{
		g2.setColor(Color.YELLOW) ;
		g2.fill(body);
	}

}
