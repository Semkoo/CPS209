import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.Random;


public class SlowPrey extends Creature
{
	Ellipse2D.Double body;
	int updateRate;
	static int moveCount;
	int distanceMoved;
	int direction,rn;
	Random random = new Random();
		
	public SlowPrey(int x, int y, int width, int height, int envW, int envH)
	{
		super(x, y, width, height, envW, envH);
	    body = new Ellipse2D.Double(x,y,width,height);
	    updateRate = random.nextInt(10) + 10;
	    moveCount  = 0;
	    rn         = random.nextInt(5) + 1;
	    direction  = 1;
	    distanceMoved = 0;
	}
	
	public boolean collide(MoveableShape other)
	{
		return false;
	}
	
	public void move()
	{
		int newX = getX();
		int newY = getY();
		// Simple back and forth movement pattern
		
		if ((moveCount % updateRate) == 0)	// move creature every 'updateRate' times move() called 
		{
			newX = getX() + direction; 
			distanceMoved++;
			
			if (newX+getWidth() >= environmentWidth)
			{
				newX = environmentWidth - getWidth();
				distanceMoved = 0;
				direction *= -1;
			}
			else if (newX <= 0)
			{
				newX = 1;
				distanceMoved = 0;
				direction *= -1;
			}
			if (newY <= 0)
				newY = 1;
			else if ((newY+getHeight()) >= environmentHeight)
				newY = environmentHeight-getHeight();
			
			// Change direction once it has moved 'rn' times body width
			if (distanceMoved >= rn*getWidth())
			{
			    distanceMoved = 0;
				direction *= -1;
			}
			
		    body.setFrame(newX,newY,getWidth(),getHeight());
		    setX(newX);
		    setY(newY);
		}
		
		moveCount++;
	}
	public void draw(Graphics2D g2)
	{
		g2.setColor(Color.RED) ;
		g2.fill(body);
	}
}
