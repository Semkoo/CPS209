import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.util.Random;


public class SmartPrey extends Creature
{
	Ellipse2D.Double body;
	boolean evasiveAction;
	int evadeDirectionX;
	int evadeDirectionY;
		
	public SmartPrey(int x, int y, int width, int height, int envW, int envH)
	{
		super(x, y, width, height, envW, envH);
	    body = new Ellipse2D.Double(x,y,width,height);
	    evasiveAction = false;
	    evadeDirectionX = 0;
	    evadeDirectionY = 0;
	}
	
	public boolean collide(MoveableShape other)
	{
		Creature otherCreature = (Creature)other;
		double dist = Point2D.distance(this.getX(),this.getY(),otherCreature.getX(),otherCreature.getY());

		if (dist < 2*otherCreature.getWidth())
		{
			evadeDirectionX = (this.getX() - otherCreature.getX() > 0)? 1 : -1;
			evadeDirectionY = (this.getY() - otherCreature.getY() > 0)? 1 : -1;
			evasiveAction = true;
		}
		else 
			evasiveAction = false;
		return evasiveAction;
	}
	
	public void move()
	{
		int newX = getX();
		int newY = getY();
		
		if (evasiveAction)
		{
			newX = getX() + 2 * evadeDirectionX;
			newY = getY() + 2 * evadeDirectionY;
			
			if (newX+getWidth() >= environmentWidth)
			{
				newX = environmentWidth - getWidth();
				
			}
			else if (newX <= 0)
			{
				newX = 1;
			}
			if (newY <= 0)
			{
				newY = 1;
			}
			else if ((newY+getHeight()) >= environmentHeight)
			{
				newY = environmentHeight - getHeight();
			}
			body.setFrame(newX,newY,getWidth(),getHeight());
		    setX(newX);
		    setY(newY);
		    evasiveAction = false;
		}
    }
	
	public void draw(Graphics2D g2)
	{
		g2.setColor(Color.GREEN) ;
		g2.fill(body);
	}
}


